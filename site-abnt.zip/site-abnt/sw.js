const V = "abnt-v3", SHELL = ["./", "index.html", "icon.svg", "logo.svg", "manifest.webmanifest", "icon-192.png", "icon-512.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(V).then(c => Promise.allSettled(SHELL.map(u => c.add(u)))).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const r = e.request, u = new URL(r.url);
  if(r.method !== "GET" || (u.origin !== location.origin && u.hostname !== "cdnjs.cloudflare.com")) return;
  e.respondWith(caches.match(r).then(hit => {
    const net = fetch(r).then(res => { if(res.ok || res.type === "opaque"){ const cp = res.clone(); caches.open(V).then(c => c.put(r, cp)); } return res; }).catch(() => hit || caches.match("index.html"));
    return hit || net;
  }));
});
