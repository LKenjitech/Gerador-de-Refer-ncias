# Gerador de Referências ABNT

App web (PWA) para montar referências, citações, notas de rodapé e fichamentos conforme a ABNT (NBR 6023 e NBR 10520).

## Arquivos
- `index.html`: o app inteiro
- `manifest.webmanifest` e `sw.js`: tornam o site instalável e disponível sem internet
- `icon.svg`, `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `apple-touch-icon.png`: ícones
- `logo.svg`: logo horizontal

## Publicar no GitHub Pages
1. Crie um repositório e envie todos os arquivos para a raiz.
2. Em **Settings > Pages**, escolha a branch `main` e a pasta `/ (root)`.
3. O app fica em `https://SEU-USUARIO.github.io/NOME-DO-REPOSITORIO/` (precisa de HTTPS, que o GitHub Pages já oferece).

## Instalar como app
- Android e computador: botão "Instalar app" (Configurações ou página inicial) ou menu do navegador.
- iPhone: Compartilhar > Adicionar à Tela de Início.

## Só o index.html
O `index.html` funciona sozinho: ele embute o manifesto, os ícones e o logo. Os outros arquivos são opcionais; o `sw.js` só é necessário para o app abrir sem internet.

## Se o app não instalar
- Confirme que **todos** os arquivos do zip estão na mesma pasta do `index.html` no repositório (principalmente `manifest.webmanifest`, `sw.js` e os `icon-*.png`).
- Abra o app, vá em **Configurações > Verificar instalação** e veja qual item falha.
- Aguarde 1 a 2 minutos após enviar os arquivos e recarregue a página duas vezes.

## Recursos
- Referências: livro, capítulo, artigo, jornal, TCC/dissertação/tese, evento e site, com aviso de campos faltando.
- Busca automática por **DOI** (Crossref) e por **ISBN** (Google Livros e Open Library).
- **Minha lista**: salva as referências no aparelho, em ordem alfabética, com "Copiar todas" (mantém o negrito ao colar no Word).
- Citação direta, indireta, apud, notas de rodapé e fichamento.
- Análise com IA opcional: em Configurações, cole uma chave da API da Anthropic (fica só no navegador).

## Paleta
Azul principal `#1E3A8A`, azul secundário `#3B82F6`, cinza neutro `#64748B`, fundo `#F8FAFC`.

## Autor
by Lucas Kenji
